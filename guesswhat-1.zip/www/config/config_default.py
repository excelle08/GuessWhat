__author__ = 'Excelle'

configs = {
    'db': {
        'host': '127.0.0.1',
        'port': 3306,
        'user': 'root',
        'password': 'zgsdzlx',
        'database': 'atomsquare_unidata'
    },
    'session': {
        'secret': '36a451df3681e9b3'
    }
}